package com.ace3i.katabank_client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KatabankClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
