package com.ace3i.katabank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KatabankApplicationTests {

	@Test
	void contextLoads() {
	}

}
