package com.ace3i.katabank_synchronisation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KatabankSynchronisationApplicationTests {

	@Test
	void contextLoads() {
	}

}
