package com.ace3i.katabank_paiement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KatabankPaiementApplication {

	public static void main(String[] args) {
		SpringApplication.run(KatabankPaiementApplication.class, args);
	}

}
