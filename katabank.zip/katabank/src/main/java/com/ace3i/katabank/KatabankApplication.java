package com.ace3i.katabank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KatabankApplication {

	public static void main(String[] args) {
		SpringApplication.run(KatabankApplication.class, args);
	}

}



