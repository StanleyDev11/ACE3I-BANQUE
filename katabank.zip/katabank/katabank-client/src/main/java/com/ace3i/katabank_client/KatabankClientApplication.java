package com.ace3i.katabank_client;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KatabankClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(KatabankClientApplication.class, args);
	}

}
