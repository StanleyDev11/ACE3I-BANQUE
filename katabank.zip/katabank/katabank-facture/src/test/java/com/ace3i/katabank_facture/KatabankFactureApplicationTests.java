package com.ace3i.katabank_facture;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KatabankFactureApplicationTests {

	@Test
	void contextLoads() {
	}

}
