package com.ace3i.katabank_paiement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KatabankPaiementApplicationTests {

	@Test
	void contextLoads() {
	}

}
