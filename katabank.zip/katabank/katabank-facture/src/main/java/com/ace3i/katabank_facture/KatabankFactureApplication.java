package com.ace3i.katabank_facture;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KatabankFactureApplication {

	public static void main(String[] args) {
		SpringApplication.run(KatabankFactureApplication.class, args);
	}

}
